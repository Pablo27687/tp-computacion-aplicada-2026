history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
cat /etc/resolv.conf v
powerofff
poweroff
sudo cat /etc/hash 
cd /usr/local/bin/
ls -ltr
ls -l
base64 -d -i < cat /etc/hash 
cat /etc/hash 
cat /etc/hash  > base64 -d -i
cat /etc/hash | base64 -d -i
rm /etc/hash 
chatrr -i /etc/hash 
cd /etc/
ls -l |has
ls -l |hash
ls -ltr 
chatrr +i hash 
chattr -i /etc/hash 
rm /etc/hash 
ls -l
reboot
history
shutdown now
whoami
hostname
hostnamectl set-hostname TPServer
hostname
cat/etc/debian_version
cat /etc/debian_version
df -h
dpkg --audit
dpkg --audit
cat /etc/apt/sources.list
ls -l /etc/apt/sources.list.d/
ip -br addr
cat /etc/network/interfaces
ls -l /etc/network/interfaces.d/
poweroff
apt update
poweroff
apt update
ip -br addr
cat /etc/network/interfaces
vi /etc/network/interfaces
ifup enp0s1
apt update
apt update
getent hosts deb.debian.org
cat /etc/apt/sources.list
cp -n /etc/apt/sources.list /etc/apt/sources.listpre-repos
vi /etc/apt/sources.list
apt update
df -h/
df -h /
apt -s upgrade
upt upgrade
apt upgrade
dpkg --audit
vi /etc/apt/sources.list
apt update
apt upgrade
dpkg --audit
apt list --upgradable
apt-mark showhold
cp -nv /etc/apt/sources.list /etc/apt/sources.list.bullseye
vi /etc/apt/sources.list
apt updat4e
apt update
apt upgrade
dpkg --audit
apt full-upgrade
dpkg --audit
cat /etc/debian_version
apt list --apgradable
apt list --upgradable
reboot
apt instal openssh-server
apt install openssh-server
ls -la /root

tar -tzf /root/Material_Adicional_TPVMCA.tar.gz
tar -xzkf /root/Material_Adicional_TPVMCA.tar.gz -C /root/Matarial_Adicional_TPVMCA/clave_publica.pib
tar -xzkf /root/Material_Adicional_TPVMCA.tar.gz -C /root Material_Adicional_TPVMCA/clave_publica.pub
ls -l /root/Material_Adicional_TPVMCA/clave_publica.pub
ls -la /root/.ssH
ls -la /root/.ssh
cp -n /root/Material_Adicional_TPVMCA/clave_publica.pub /root/.ssh/authorized_keys
chmod 600 /root/.ssh/authorized_keys
ls -l /root/.ssh/authorized_keys
sshd -T | grep -i permitrootlogin
ip -br a
ssh-keygen -lf /etc/ssh/ssh_host_ed25519_key.pub
apt install apache2 php libapache2-mod-php php-mysql mariadb-server
poweroff
tar -xzkf /root/Material_Adicional_TPVMCA.tar.gz -C /root Material_Adicional_TPVMCA/index.php Material_Adicional_TPVMCA/logo.png Material_Adicional_TPVMCA/db.sql
mariadb < /root/Material_Adicional_TPVMCA/db.sql
cp -n /root/Material_Adicional_TPVMCA/index.php /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
